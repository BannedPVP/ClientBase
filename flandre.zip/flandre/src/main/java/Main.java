
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import me.flandre.flandreClinet.flandre;
@Mod(modid = "flandreclient", version = "b1")
public class Main {

    @EventHandler
    public void init(FMLInitializationEvent event) {
        flandre.instance = new flandre();
        flandre.instance.init();
    }
}

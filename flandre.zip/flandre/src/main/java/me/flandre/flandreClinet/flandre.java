package me.flandre.flandreClinet;

import me.flandre.flandreClinet.ClickGUI.ClickGui;
import me.flandre.flandreClinet.module.Category;
import me.flandre.flandreClinet.module.Module;
import me.flandre.flandreClinet.module.ModuleManager;
import me.flandre.flandreClinet.setting.SettingsManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import org.lwjgl.input.Keyboard;

public class flandre
{
    public static flandre instance;
    public ModuleManager moduleManager;
    public SettingsManager settingsManager;
    public ClickGui clickGui;

    public void init() {
        MinecraftForge.EVENT_BUS.register(this);
        settingsManager = new SettingsManager();
        moduleManager = new ModuleManager();
        clickGui = new ClickGui();
    }

    @SubscribeEvent
    public void key(KeyInputEvent e) {
        if (Minecraft.getMinecraft().theWorld == null || Minecraft.getMinecraft().thePlayer == null)
            return;
        try {
            if (Keyboard.isCreated()) {
                if (Keyboard.getEventKeyState()) {
                    int keyCode = Keyboard.getEventKey();
                    if (keyCode <= 0)
                        return;
                    for (Module m : moduleManager.modules) {
                        if (m.getKey() == keyCode && keyCode > 0) {
                            m.toggle();
                        }
                    }
                }
            }
        } catch (Exception q) { q.printStackTrace(); }
    }


    public GuiScreen getClickGui() {
        return clickGui;
    }

    public void setClickGui(GuiScreen clickGui) {
        this.clickGui = (ClickGui) clickGui;
    }

    public Module[] getModulesInCategory(Category category) {
        return new Module[0];
    }
}

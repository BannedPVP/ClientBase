package me.flandre.flandreClinet.module;

public enum Category    {
    COMBAT, MOVEMENT, PLAYER, RENDER, MISC
}


package me.flandre.flandreClinet.Render;

import me.flandre.flandreClinet.module.Category;
import me.flandre.flandreClinet.module.Module;
import org.lwjgl.input.Keyboard;
import static me.flandre.flandreClinet.flandre.instance;

public class ClickGUI extends Module {

        public ClickGUI() {
        super("ClickGUI", "Allows you to enable and disable modules", Category.RENDER);
        this.setKey(Keyboard.KEY_HOME);
        }

        @Override
        public void onEnable() {
        super.onEnable();
        mc.displayGuiScreen(instance.getClickGui());
        this.setToggled(false);
        }

        }